"""
EAA V4 — Phase 7: Cross-Session Memory
=======================================
Implements persistent conversation memory across sessions, enabling
agents to maintain context from previous interactions.

Modules:
    session_transcript — JSONL persistence for conversation turns with
                         token-aware /resume (6K hard cap)
    session_memory     — Rolling Markdown notes compaction (zero API calls)
    memory_extractor   — Background heuristic extraction daemon with
                         sliding-window support for long transcripts
    prompt_history     — Global project-scoped command-line history in JSONL

Integration points:
    - Phase 3: context_manager.py, token_tracker.py (estimate_tokens)
    - Phase 4: prompt_assembler.py, memory_loader.py (MemoryLoadResult)

Amendments from Blueprint v1.1:
    Amendment 1: Transient UI Spinner (Phase 6, not here)
    Amendment 2: Daemon Thread Idle Trigger
    Amendment 3: SIGINT VRAM Cleanup Trap (Phase 6)
    Amendment 4: Token-Aware /resume with 6K cap
    Amendment 5: JSONDecodeError Intercept
    Amendment 6: Sliding Window 4K chunk extraction
"""

__all__ = [
    "SessionTranscript",
    "SessionMemory",
    "MemoryEntry",
    "MemoryExtractor",
    "PromptHistory",
]

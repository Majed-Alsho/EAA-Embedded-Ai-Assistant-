"""
EAA V4 - Phase 6: Self-Healing Loop
=====================================
Implements the self-healing error recovery and validation subsystem.

Modules:
  - error_handler: 3-tier max_output_tokens recovery cascade + JSONDecodeError intercept
  - validation_hooks: Post-edit syntax validation + Transient UI Spinner
  - concurrent_isolation: Sibling-aware failure containment for parallel tool executions

This package provides the final layer of robustness: when a worker produces
malformed output, a truncated response, or a syntax error, the self-healing
loop catches it and either retries automatically or escalates to the Master.
"""

from error_handler import (
    RecoveryAction,
    RecoveryResult,
    ErrorHandler,
    create_error_handler,
)
from validation_hooks import (
    ValidationFailure,
    ValidationHook,
    PythonSyntaxHook,
    ValidationHookRegistry,
    HealingSpinner,
)
from concurrent_isolation import (
    TaskStatus,
    SiblingGroup,
    ConcurrentIsolationController,
    create_isolation_controller,
)

__all__ = [
    # error_handler
    "RecoveryAction",
    "RecoveryResult",
    "ErrorHandler",
    "create_error_handler",
    # validation_hooks
    "ValidationFailure",
    "ValidationHook",
    "PythonSyntaxHook",
    "ValidationHookRegistry",
    "HealingSpinner",
    # concurrent_isolation
    "TaskStatus",
    "SiblingGroup",
    "ConcurrentIsolationController",
    "create_isolation_controller",
]
